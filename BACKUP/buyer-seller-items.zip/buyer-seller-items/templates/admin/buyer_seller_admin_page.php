<div class="buy_sell_wrapper">
	<div class="buy_sell_container">
		<div class="row">
			<div class="col">
				<h2>Registration Form Shortcode</h2>
			</div>
			<div class="col">
				<center><code>[buyer_seller_registration_form]</code></center>
			</div>
		</div>
		<!-- Second Row -->
		<div class="row">
			<div class="col">
				<h2>Login Form Shortcode</h2>
			</div>
			<div class="col">
				<center><code>[buyer_seller_login_form]</code></center>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<h2>Items shortcode for widget (posts= number of items you want to dispaly)</h2>
			</div>
			<div class="col">
				<code>[widget_buyer_seller_items posts= 4]</code>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<h2> Latest Items shortcode for widget (posts= number of items you want to dispaly)</h2>
			</div>
			<div class="col">
				<code>[widget_buyer_seller_items_latest posts= 4]</code>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<h2> Multiple Functionality Shortcode</h2>
			</div>
			<div class="col">
				<code>For Displaying Latest Products:<br> [buyer_seller posts="latest"] <br><br>
					For Displaying Buyer Products:<br> [buyer_seller posts="selling"] <br><br>
					For Displaying Offered Products:<br> [buyer_seller posts="offered"] <br></code>
			</div>
		</div>
	</div>
</div>